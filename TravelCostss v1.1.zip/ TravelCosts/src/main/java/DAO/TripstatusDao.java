package DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import Model.Tripstatus;
import Repository.TripstatusRepository;

public class TripstatusDao {
	
	@Autowired
	TripstatusRepository tRep;
	
	
	public Optional<Tripstatus> finOne(Long t) 
	{
		return tRep.findById(t);
		
	}

	
	public Tripstatus save(Tripstatus t) 
	{
		return tRep.save(t);
		
	}
	
	public List<Tripstatus> findAll(Tripstatus t){
		return tRep.findAll();
	}
	
	public void delete (Tripstatus t) 
	{
		 tRep.delete(t);
		
	}
	
}
