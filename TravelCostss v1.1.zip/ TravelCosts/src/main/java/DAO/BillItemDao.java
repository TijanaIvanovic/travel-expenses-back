package DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import Model.Billitem;
import Repository.BillitemRepository;

public class BillItemDao {
	
	@Autowired
	BillitemRepository BillitemRep;
	
	public Optional<Billitem> finOne(Long id) 
	{
		return BillitemRep.findById(id);
		
	}

	
	public Billitem save(Billitem b) 
	{
		return BillitemRep.save(b);
		
	}
	
	public List<Billitem> findAll(Billitem b){
		return BillitemRep.findAll();
	}
	
	public void delete (Billitem b) 
	{
		 BillitemRep.delete(b);
		
	}

}
