package DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import Model.Bill;
import Repository.BillRepository;

public class BillDao {
	
	@Autowired
	BillRepository billRep;
	
	public Optional<Bill> finOne(Long billId) 
	{
		return billRep.findById(billId);
		
	}

	
	public Bill save(Bill b) 
	{
		return billRep.save(b);
		
	}
	
	public List<Bill> findAll(Bill b){
		return billRep.findAll();
	}
	
	public void delete (Bill b) 
	{
		 billRep.delete(b);
		
	}
	
}
