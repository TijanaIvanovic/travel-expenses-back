package DAO;

import java.util.List;
import java.util.Optional;

import Model.Users;
import Repository.UserRepository;

public class UsersDao {
	
	UserRepository uRep;
	
	public Optional<Users> finOne(Long u) 
	{
		return uRep.findById(u);
		
	}

	
	public Users save(Users u) 
	{
		return uRep.save(u);
		
	}
	
	public List<Users> findAll(Users u){
		return uRep.findAll();
	}
	
	public void delete (Users u) 
	{
		 uRep.delete(u);
		
	}
	
}
