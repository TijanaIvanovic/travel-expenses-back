package DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import Model.Tripofemployee;
import Repository.TripofemployeeRepository;

public class TripofemployeeDao {

	@Autowired
	TripofemployeeRepository toe;
	
	public Optional<Tripofemployee> finOne(Long t) 
	{
		return toe.findById(t);
		
	}

	
	public Tripofemployee save(Tripofemployee t) 
	{
		return toe.save(t);
		
	}
	
	public List<Tripofemployee> findAll(Tripofemployee t){
		return toe.findAll();
	}
	
	public void delete (Tripofemployee t) 
	{
		 toe.delete(t);
		
	}
}
