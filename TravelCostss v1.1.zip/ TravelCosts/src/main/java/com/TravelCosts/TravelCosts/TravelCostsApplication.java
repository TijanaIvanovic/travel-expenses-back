package com.TravelCosts.TravelCosts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelCostsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelCostsApplication.class, args);
	}

}
