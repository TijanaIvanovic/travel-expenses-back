package Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import Model.Price;;

public interface PriceRepository extends JpaRepository<Price, Long>{

}
