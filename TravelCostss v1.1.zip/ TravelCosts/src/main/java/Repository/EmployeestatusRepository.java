package Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import Model.Employeestatus;;

public interface EmployeestatusRepository extends JpaRepository<Employeestatus, Long>{

}
