

package Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import Model.Billitem;

public interface BillitemRepository extends JpaRepository<Billitem, Long>{

}