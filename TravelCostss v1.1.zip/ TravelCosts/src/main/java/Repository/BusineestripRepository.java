package Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import Model.Busineestrip;

public interface BusineestripRepository extends JpaRepository<Busineestrip, Long>{

}
