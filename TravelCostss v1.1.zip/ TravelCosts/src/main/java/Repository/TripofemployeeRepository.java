package Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import Model.Tripofemployee;

public interface TripofemployeeRepository extends JpaRepository<Tripofemployee, Long>{

}
