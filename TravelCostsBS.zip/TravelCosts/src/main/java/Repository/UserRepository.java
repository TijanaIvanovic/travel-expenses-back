package Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Model.Users;

public interface UserRepository extends JpaRepository<Users, Long>{

}
