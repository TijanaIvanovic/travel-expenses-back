package Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import Model.Tripstatus;

public interface TripstatusRepository extends JpaRepository<Tripstatus, Long>{

}