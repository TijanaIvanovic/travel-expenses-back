package Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import Model.Destination;

public interface DestinationRepository extends JpaRepository<Destination, Long>{

}
