package DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import Model.Price;
import Repository.PriceRepository;

public class PriceDao {
	
	@Autowired
	PriceRepository pRep;
	
	public Optional<Price> finOne(Long p) 
	{
		return pRep.findById(p);
		
	}

	
	public Price save(Price p) 
	{
		return pRep.save(p);
		
	}
	
	public List<Price> findAll(Price p){
		return pRep.findAll();
	}
	
	public void delete (Price p) 
	{
		pRep.delete(p);
		
	}
	
}
