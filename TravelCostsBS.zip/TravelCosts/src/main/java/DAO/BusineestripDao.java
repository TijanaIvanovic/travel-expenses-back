package DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import Model.Busineestrip;
import Repository.BusineestripRepository;

public class BusineestripDao {
	
	@Autowired
	BusineestripRepository bRep;
	
	public Optional<Busineestrip> finOne(Long bRepid) 
	{
		return bRep.findById(bRepid);
		
	}

	
	public Busineestrip save(Busineestrip b) 
	{
		return bRep.save(b);
		
	}
	
	public List<Busineestrip> findAll(Busineestrip b){
		return bRep.findAll();
	}
	
	public void delete (Busineestrip b) 
	{
		 bRep.delete(b);
		
	}
	
}
