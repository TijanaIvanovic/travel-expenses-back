package DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import Model.Employeestatus;
import Repository.EmployeestatusRepository;

public class EmployeestatusDao {
	@Autowired
	EmployeestatusRepository empStat;
	
	public Optional<Employeestatus> finOne(Long empid) 
	{
		return empStat.findById(empid);
		
	}

	
	public Employeestatus save(Employeestatus emp) 
	{
		return empStat.save(emp);
		
	}
	
	public List<Employeestatus> findAll(Employeestatus emp){
		return empStat.findAll();
	}
	
	public void delete (Employeestatus emp) 
	{
		 empStat.delete(emp);
		
	}
}
